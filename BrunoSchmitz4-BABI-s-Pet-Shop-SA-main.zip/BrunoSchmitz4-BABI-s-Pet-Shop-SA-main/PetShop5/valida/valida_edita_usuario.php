<?php

session_start();

include_once'../adm/config/conexao.php';

if(!isset($_SESSION['msg'])) {
    echo $_SESSION['msg'];
    unset ($_SESSION['msg']);
}


$edita_cad_usuario = filter_input(INPUT_POST, 'editaUsuario', FILTER_SANITIZE_STRING);


if(!empty($edita_cad_usuario)){
    //echo '<br>Deu certo!';
    
//    $cripto_senha = password_hash($dados_cadastro['senha'],PASSWORD_DEFAULT);
    
    $query_edita_usuarios = "UPDATE usuarios SET nome='$nome', email='$email', senha='$senha', 
    telefone='$telefone', complemento='$complemento', nivel_acesso_id='$nivel_acesso_id', 
    cep_id='$cep_id', created='$created'), modified=NOW() WHERE id='$id_user'";
    
    $result_edita_user = $conn->prepare($query_edita_usuarios);
    $result_edita_user->execute();
    
    if(($result_edita_user) AND ($result_edita_user->rowCount() != 0)){ 
        $row_edita_usuario = $result_edita_user->fetch(PDO::FETCH_ASSOC);
        $_SESSION['msg'] = "<h2><p style='color:green'>Cadastrado com sucesso!</p></h2>";
        header("Location:..\pags\cliente.php");
        
    } else {
        $_SESSION['msg'] = "<h2><p style='color:red'>Não foi possível inserir usuário!</p></h2>";
        header("Location:..\adm\cadastrar.php");
    }    
    
} else {
    $_SESSION['msg'] = "<h2><p style='color:red'>Não foi possível cadastrar!</p></h2>";
    header("Location:..\adm\cadastrar.php");
}



?>