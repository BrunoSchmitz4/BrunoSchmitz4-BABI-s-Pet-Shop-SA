<?php 

session_start();

include_once '../adm/config/conexao.php';

// if(!isset($_SESSION['id']) AND !isset($_SESSION['nome'])){
//     $_SESSION['msg'] = "<p style='color: #ff0000'>Erro: necessário realizar o login para acessar a página!</p>";
//     header("Location:../pags/cliente.php");
// }

$id_user = $_GET['$id'];
echo $id_user;

$query_edita_serv = "SELECT id, nome, email, senha, telefone, complemento, nivel_acesso_id, cep_id, created, modified FROM usuarios WHERE id = $id_user LIMIT 1";
$resultado_editar = $conn->prepare($query_edita_serv);
$resultado_editar->execute();

if(($resultado_editar) AND ($resultado_editar->rowCount() != 0)) {
    $row_edit_user = $resultado_editar->fetch(PDO::FETCH_ASSOC);
}

?>

<html>
    <head> 
        <meta charset="UTF-8">
        <link rel='stylesheet' href='../css/style.css'/>
        <title>Edita Cadastro</title>
    </head>
    <body>
        <div class ="center">
            <?php
            if(isset($_SESSION['msg'])){
                echo $_SESSION['msg'];
                unset ($_SESSION['msg']);
            }

            ?>
            <h1>Cadastrar usuário</h1> 
        
            <form method="POST" action="../valida/valida_edita_usuario.php">
                
            <div class="txt_field">
                
                <input type="text" name="nome" value="<?php echo $row_edit_user['nome']; ?>"   required>
                <label>Nome:</label>
            </div>
                
            <div class="txt_field">
                      
                <input type="email" name="email" value="<?php echo $row_edit_user['email']; ?>" required>
                <label>E-mail:</label>
                <!--<br><br> -->
            </div>
                
            <div class="txt_field">      
                
                <input type="password" name="senha" value="<?php echo $row_edit_user['senha']; ?>" required>
                <label>Senha:</label>                           
            </div>
                
            <div class="txt_field">   
                
                <input type="tel" name="telefone" value="<?php echo $row_edit_user['telefone']; ?>" required>
                <label>Telefone:</label>                    
            </div>
                
            <div class="txt_field">
                
                <input type="text" name="complemento" value="<?php echo $row_edit_user['complemento']; ?>" required>
                <label>Complemento:</label>
            </div>
                
            <label>CEP:</label>
            <select name="cep_id" id="cep_id" value="<?php echo $row_edit_user['cep_id']; ?>"> 
                <?php
                echo "<option value=''>Selecione</option>";
                while ($row_cep = $result_cep->fetch(PDO::FETCH_ASSOC)) {
                    extract($row_cep);
                    echo "<option value = $id>$cep - $logradouro</option>";
                }
                ?>
            </select>
            <br><br>            

            <input type="submit" name="editaUsuario" value="Salvar">