Aqui podemos listar o andamento do projeto: comentando as atualizações de cada página , o que falta ou o que precisa ser implementado/atualizado/reparado etc

_______________________________________________

Parte: Login
Index.php (completo)
Custom.css (completo)
Valida_login.php (completo)
-----------------------------------------------

Parte: Cadastro
cadastrar.php (completo)
Style.css (completo)
Valida_cadastro (completo)
-----------------------------------------------

Parte: conexão
Conexao.php (completo)
-----------------------------------------------

Parte: administrador
Administrador.php (incompleto)
Administrador.css (Não Iniciado)
Valida_servico (completo)
-----------------------------------------------

Parte: colaborador
Colaborador.php (incompleto)
Colaborador.css (incompleto)
-----------------------------------------------

Parte: cliente
Cliente.php (Completo)
Cliente.css (completo)
Clientelogged.php(Completo)
Cliente_loggout.php(Completo)
-----------------------------------------------

Parte: extras
Contato.php (Completo)
Sobre.php (Completo)
Contato.css (Completo)
Sobre.css (Completo)
Font.css (completo)

-----------------------------------------------

Páginas em geral

Conjunto com paletas de cores indicadas para pet shop, caso precisemos de ideias ao estilizar determinados elementos do site:

  #C86873 #232C44  . #4A443F,   #385C5D  #898383
  #90A4A9  #43403C, #797B7A  #AB9177, #6A5442  #BAAA94,  ou #A79487 ou #AA9181 #38211F */